// Questions
// Aim: To implement the program to remove left recursion from grammar and find first
// and follow of the given grammar
// Objective: Develop a program to find:
// a. FIRST set
// b. FOLLOW set
// for given grammar.


#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 10

char productions[MAX][10] = {
    "E=TG", 
    "G=+TG", 
    "G=e", 
    "T=FH", 
    "H=*FH", 
    "H=e", 
    "F=(E)", 
    "F=id"
};

int num_productions = 8;
char first[MAX][MAX], follow[MAX][MAX];
char non_terminals[MAX];
int nt_count = 0;

int is_non_terminal(char symbol) {
    return symbol >= 'A' && symbol <= 'Z';
}

void add_to_set(char *set, char value) {
    if (strchr(set, value) == NULL) {
        int len = strlen(set);
        set[len] = value;
        set[len + 1] = '\0';
    }
}

void compute_first(char nt, char *result);

void compute_first(char nt, char *result) {
    for (int i = 0; i < num_productions; i++) {
        if (productions[i][0] == nt) {
            char *rhs = strchr(productions[i], '=') + 1;
            if (!is_non_terminal(rhs[0])) {
                add_to_set(result, rhs[0]);
            } else {
                if (rhs[0] != nt) {
                    char temp[MAX] = "";
                    compute_first(rhs[0], temp);
                    for (int j = 0; temp[j]; j++) {
                        add_to_set(result, temp[j]);
                    }
                }
            }

            if (rhs[0] == 'e') {
                add_to_set(result, 'e');
            }
        }
    }
}

void compute_follow(char nt, char *result) {
    if (nt == 'E') {
        add_to_set(result, '$');  // start symbol
    }

    for (int i = 0; i < num_productions; i++) {
        char *rhs = strchr(productions[i], '=') + 1;
        for (int j = 0; rhs[j]; j++) {
            if (rhs[j] == nt) {
                if (rhs[j + 1] != '\0') {
                    if (!is_non_terminal(rhs[j + 1])) {
                        add_to_set(result, rhs[j + 1]);
                    } else {
                        char temp[MAX] = "";
                        compute_first(rhs[j + 1], temp);
                        for (int k = 0; temp[k]; k++) {
                            if (temp[k] != 'e')
                                add_to_set(result, temp[k]);
                        }
                    }
                } else {
                    if (productions[i][0] != nt) {
                        char temp[MAX] = "";
                        compute_follow(productions[i][0], temp);
                        for (int k = 0; temp[k]; k++) {
                            add_to_set(result, temp[k]);
                        }
                    }
                }
            }
        }
    }
}

int main() {
    printf("Grammar productions:\n");
    for (int i = 0; i < num_productions; i++) {
        printf("%s\n", productions[i]);
        char nt = productions[i][0];
        if (strchr(non_terminals, nt) == NULL) {
            non_terminals[nt_count++] = nt;
        }
    }

    printf("\nFIRST sets:\n");
    for (int i = 0; i < nt_count; i++) {
        char nt = non_terminals[i];
        char res[MAX] = "";
        compute_first(nt, res);
        strcpy(first[i], res);
        printf("FIRST(%c) = { ", nt);
        for (int j = 0; res[j]; j++) {
            printf("%c ", res[j]);
        }
        printf("}\n");
    }

    printf("\nFOLLOW sets:\n");
    for (int i = 0; i < nt_count; i++) {
        char nt = non_terminals[i];
        char res[MAX] = "";
        compute_follow(nt, res);
        strcpy(follow[i], res);
        printf("FOLLOW(%c) = { ", nt);
        for (int j = 0; res[j]; j++) {
            printf("%c ", res[j]);
        }
        printf("}\n");
    }

    return 0;
}
