// Questions
// Aim : To implement any code optimization techniques
// Objective: Develop a program to implement following code optimization techniques:
// a. Common sub-expression elimination
// b. Reduction in strength 

#include <stdio.h>    
#include <string.h>   
#include <stdlib.h> 
// Function to trim leading and trailing whitespace 
void trim(char *str) { 
    char *end; 
    while (*str == ' ') str++; 
    end = str + strlen(str) - 1; 
    while (end > str && (*end == ' ' || *end == '\n')) *end-- = '\0'; 
} 
// Common Sub-expression Elimination 
void common_subexpression_elimination(char statements[][100], int stmt_count) { 
    printf("\n    Performing Common Sub-expression Elimination:\n"); 
    char seen[100][100]; 
    char lhs_map[100][100]; 
    int seen_count = 0; 
    for (int i = 0; i < stmt_count; i++) { 
        char lhs[100], rhs[100]; 
 
        // Find '=' position 
        char *eq = strchr(statements[i], '='); 
        if (!eq) continue; 
 
        *eq = '\0'; 
        strcpy(lhs, statements[i]); 
        strcpy(rhs, eq + 1); 
        trim(lhs); 
        trim(rhs); 
 
        int found = 0; 
        for (int j = 0; j < seen_count; j++) { 
            if (strcmp(rhs, seen[j]) == 0) { 
                printf("    Replacing `%s = %s` with `%s = %s`\n", lhs, rhs, lhs, lhs_map[j]); 
                sprintf(statements[i], "%s = %s", lhs, lhs_map[j]); 
                found = 1; 
                break; 
            } 
        } 
 
        if (!found) { 
            strcpy(seen[seen_count], rhs); 
            strcpy(lhs_map[seen_count], lhs); 
            seen_count++; 
            sprintf(statements[i], "%s = %s", lhs, rhs); 
        } 
    } 
    printf("Optimized code after Common Sub-expression Elimination:\n"); 
    for (int i = 0; i < stmt_count; i++) { 
        printf("%s\n", statements[i]); 
    } 
} 
// Strength Reduction 
void strength_reduction(char statements[][100], int stmt_count) { 
    printf("\n⚙ Performing Strength Reduction:\n"); 
 
    for (int i = 0; i < stmt_count; i++) { 
        char lhs[100], op1[100], op[5], op2[100]; 
 
        if (sscanf(statements[i], "%s = %s %s %s", lhs, op1, op, op2) == 4) { 
            if (strcmp(op, "*") == 0 && strcmp(op2, "2") == 0) { 
                printf("  Replacing `%s` with `%s = %s + %s`\n", statements[i], lhs, op1, 
op1); 
                sprintf(statements[i], "%s = %s + %s", lhs, op1, op1); 
            } else if (strcmp(op, "*") == 0 && strcmp(op2, "4") == 0) { 
                printf("  Replacing `%s` with `%s = (%s + %s) + (%s + %s)`\n", 
statements[i], lhs, op1, op1, op1, op1); 
                sprintf(statements[i], "%s = (%s + %s) + (%s + %s)", lhs, op1, op1, op1, 
op1); 
            } 
        } 
    } 
 
    printf("Optimized code after Strength Reduction:\n"); 
    for (int i = 0; i < stmt_count; i++) { 
        printf("%s\n", statements[i]); 
    } 
} 
int main() { 
    char statements[100][100]; 
    int stmt_count = 0; 
    printf("Enter 3-address code statements (e.g., t1 = a + b). Type 'done' to finish:\n"); 
 
    while (1) { 
        char line[100]; 
        printf(">> "); 
        fgets(line, sizeof(line), stdin); 
        line[strcspn(line, "\n")] = 0;  // Remove newline character 
 
        if (strcmp(line, "done") == 0) 
            break; 
 
        if (strchr(line, '=')) { 
            strcpy(statements[stmt_count++], line); 
        } 
    } 
    // Apply optimizations 
    common_subexpression_elimination(statements, stmt_count); 
    strength_reduction(statements, stmt_count); 
 
    return 0; 
} 