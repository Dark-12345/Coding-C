#  Questions
#  Aim: To implement the program to remove left recursion from grammar and find first
#  and follow of the given grammar
#  Objective: Develop a program to find:
#  a. FIRST set
#  b. FOLLOW set
#  for given grammar.


from collections import defaultdict

def find_first(grammar, non_terminal, first_sets):
    for production in grammar[non_terminal]:
        if production == 'ε':
            first_sets[non_terminal].add('ε')
        else:
            for symbol in production:
                if symbol not in grammar:  # Terminal
                    first_sets[non_terminal].add(symbol)
                    break
                else:
                    find_first(grammar, symbol, first_sets)
                    first_sets[non_terminal].update(first_sets[symbol] - {'ε'})
                    if 'ε' not in first_sets[symbol]:
                        break
            else:
                first_sets[non_terminal].add('ε')

def find_follow(grammar, start_symbol, first_sets, follow_sets):
    follow_sets[start_symbol].add('$')

    for head in grammar:
        for production in grammar[head]:
            for i in range(len(production)):
                symbol = production[i]
                if symbol in grammar:  # Only non-terminals
                    next_part = production[i + 1:]
                    if next_part:
                        for next_symbol in next_part:
                            if next_symbol not in grammar:  # Terminal
                                follow_sets[symbol].add(next_symbol)
                                break
                            else:
                                follow_sets[symbol].update(first_sets[next_symbol] - {'ε'})
                                if 'ε' not in first_sets[next_symbol]:
                                    break
                        else:
                            follow_sets[symbol].update(follow_sets[head])
                    else:
                        follow_sets[symbol].update(follow_sets[head])

grammar = {
    'E': ['TG'],
    'G': ['+TG', 'ε'],
    'T': ['FH'],
    'H': ['*FH', 'ε'],
    'F': ['(E)', 'id']
}

first_sets = defaultdict(set)
follow_sets = defaultdict(set)

for non_terminal in grammar:
    find_first(grammar, non_terminal, first_sets)

start_symbol = 'E'
find_follow(grammar, start_symbol, first_sets, follow_sets)

print("FIRST sets:")
for non_terminal, first in first_sets.items():
    print(f"FIRST({non_terminal}) = {{ {', '.join(first)} }}")

print("\nFOLLOW sets:")
for non_terminal, follow in follow_sets.items():
    print(f"FOLLOW({non_terminal}) = {{ {', '.join(follow)} }}")
