# Questions
# Aim : Using JFLAP, create a DFA from a given regular expression.
# Objective: Simulate a program to implement even number of Zero’s in String
# a. Using Jflap tool
# b. Using finite automata

def is_even_zeros(s: str) -> bool:
    state = 'A'  # 'A' = even number of 0s, 'B' = odd number of 0s

    for c in s:
        if c != '0' and c != '1':
            return False  # Invalid character

        if state == 'A':
            if c == '0':
                state = 'B'
        elif state == 'B':
            if c == '0':
                state = 'A'
        # '1' keeps the state unchanged

    return state == 'A'  # Accept if even number of 0s

def main():
    test_strings = ["0101", "1100", "101010", "1111", "0", "00", ""]
    
    for s in test_strings:
        result = is_even_zeros(s)
        print(f"String: {s:<10} ➜ {'Accepted' if result else 'Rejected'}")

if __name__ == "__main__":
    main()
