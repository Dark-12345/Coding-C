# Questions
# Aim: Write a program to implement Lexical Analyzer for given language using Finite
# Automata.
# Objective: Develop a program to implement lexical analyzer using Finite Automata

import re

MAX_TOKEN_LEN = 100
MAX_TOKENS = 1000

# Define token types and patterns
patterns = [
    {"type": "KEYWORD", "pattern": r"\b(if|else|while|return|int|float|char|void)\b"},
    {"type": "IDENTIFIER", "pattern": r"\b[a-zA-Z_][a-zA-Z0-9_]*\b"},
    {"type": "NUMBER", "pattern": r"\b\d+(\.\d+)?\b"},
    {"type": "OPERATOR", "pattern": r"[+\-*/=<>!]=?|&&|\|\|"},
    {"type": "SYMBOL", "pattern": r"[(){};,]"},
    {"type": "STRING", "pattern": r'"[^"]*"'},
    {"type": "COMMENT", "pattern": r"//.*|/\*([\s\S]*?)\*/"}
]

class Token:
    def __init__(self, token_type, value):
        self.type = token_type
        self.value = value

def match_regex(pattern, text):
    """Match regex pattern against the given text and return the matched substring."""
    match = re.match(pattern, text)
    if match:
        return match.group(0)
    return None

def lexical_analyzer(source_code):
    tokens = []
    ptr = 0
    while ptr < len(source_code):
        # Skip whitespaces and newlines
        if source_code[ptr] in [' ', '\t', '\n']:
            ptr += 1
            continue

        matched_len = 0
        matched = None

        # Try to match each pattern
        for pattern in patterns:
            matched = match_regex(pattern["pattern"], source_code[ptr:])
            if matched:
                tokens.append(Token(pattern["type"], matched))
                ptr += len(matched)
                break

        # If no pattern matched, it's an unknown token (error)
        if not matched:
            tokens.append(Token("ERROR", source_code[ptr]))
            ptr += 1

    return tokens

def main():
    source_code = """
    int main() {
        int a = 10;
        float b = 20.5;
        if (a < b) {
            a = a + 1;
        }
        // This is a comment
    }
    """
    
    tokens = lexical_analyzer(source_code)

    # Output the lexical analysis result
    print("\nLexical Analysis Output:")
    for token in tokens:
        print(f"{token.type}: {token.value}")

if __name__ == "__main__":
    main()
