# Questions
# Aim:To design and implement first pass of a two pass assembler for IBM 360/370 Processor
# Objective:Develop a program to implement first pass:
# a. To search instruction in MOT and return its length
# b. To search instruction in POT and return the routine called
# c. To generate Symbol table
# d. To generate literal table
# e. To generate intermediate code after pass 1 

def main():
    # Open input file and symbol table output file
    with open("input.txt", "r") as f1, open("symtab.txt", "w") as f3:
        lc = 0  # location counter
        sa = 0  # starting address
        op1 = 0  # operand
        len_op = 0  # length of operand
        m1 = ""
        la = ""
        op = ""
        
        # Read the first line from the input file
        la, m1, op1 = f1.readline().strip().split()
        op1 = int(op1)
        
        # If the first instruction is START
        if m1 == "START":
            sa = op1
            lc = sa
            print(f"\t\t{la}\t{m1}\t{op1}")
        else:
            lc = 0
        
        # Read the second line and process
        la, m1 = f1.readline().strip().split()

        # Loop until end of file
        while la and m1:
            op = f1.readline().strip()
            print(f"\n{lc}\t{la}\t{m1}\t{op}")
            
            # If label is not "-"
            if la != "-":
                f3.write(f"\n{lc}\t{la}\n")  # Write label to symbol table

            # Open opcode table and check for mnemonics
            with open("optab.txt", "r") as f2:
                for line in f2:
                    otp, o = line.strip().split()
                    o = int(o)
                    if m1 == otp:
                        lc += 3
                        break

            # Handle directives
            if m1 == "WORD":
                lc += 3
            elif m1 == "RESW":
                op1 = int(op)
                lc += 3 * op1
            elif m1 == "BYTE":
                if op[0] == 'X':
                    lc += 1
                else:
                    len_op = len(op) - 2
                    lc += len_op
            elif m1 == "RESB":
                op1 = int(op)
                lc += op1

            # Read next line
            la, m1 = f1.readline().strip().split()
        
        # Print the program length when END is encountered
        if m1 == "END":
            print(f"\nProgram length = {lc - sa}")

if __name__ == "__main__":
    main()


# input.txt
# START 100
# LOOP  LDA  100
#       ADD  200
#       STORE 300
#       JMP  LOOP
#       END

# optab.txt
# LDA  3
# ADD  3
# STORE  3
# JMP  3

# symtab.txt
# 100   LOOP
