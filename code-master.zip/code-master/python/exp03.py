# Questions
# Aim : To Design and Implement two pass Macro Processor
# Objective: Develop a program to implement two pass macro processor:
# a. To generate Macro definition Table(MDT)
# b. To generate Macro Name table(MNT)
# c. To generate Argument List Array(ALA)
# d. To generate expanded source code

# Input Code: 
#     "MACRO", 
#     "INCR X", 
#     "LDA X", 
#     "ADD =1", 
#     "STA X", 
#     "MEND", 
#     "START", 
#     "INCR A", 
#     "INCR B", 
#     "HLT", 

# Python equivalent of the C macro processing program

MAX_LINES = 100
MAX_LEN = 100
MAX_ARGS = 10

MDT = [None] * MAX_LINES
MNT = [''] * MAX_LINES
ALA = [[None] * MAX_ARGS for _ in range(MAX_LINES)]
expanded_code = [''] * MAX_LINES

mdt_index = 0
mnt_index = 0
expanded_index = 0


def get_macro_index(name):
    for i in range(mnt_index):
        if MNT[i] == name:
            return i
    return -1


def first_pass(source, n):
    global mdt_index, mnt_index
    inside_macro = False
    current_macro_name = ""
    current_macro_index = -1
    ala_arg_count = 0

    for i in range(n):
        line = source[i]
        tokens = line.split()

        if len(tokens) == 0:
            continue

        if tokens[0] == "MACRO":
            inside_macro = True
            continue

        if inside_macro:
            current_macro_name = tokens[0]
            MNT[mnt_index] = current_macro_name

            ala_arg_count = 0
            for j in range(1, len(tokens)):
                ALA[mnt_index][ala_arg_count] = tokens[j]
                ala_arg_count += 1

            current_macro_index = mdt_index
            mdt_index += 1  # Reserve MDT entry for macro name
            inside_macro = False
            mnt_index += 1
        elif current_macro_index != -1:
            if tokens[0] == "MEND":
                MDT[current_macro_index] = "MEND"
                current_macro_index = -1
            else:
                MDT[mdt_index] = source[i]
                mdt_index += 1


def second_pass(source, n):
    global expanded_index

    for i in range(n):
        line = source[i]
        tokens = line.split()

        if len(tokens) == 0:
            continue

        if tokens[0] == "MACRO" or tokens[0] == "MEND":
            continue

        macro_idx = get_macro_index(tokens[0])

        if macro_idx != -1:
            actual_args = tokens[1:]
            for j in range(MDT[macro_idx][0] == '' if 1 else MNT[macro_idx][0], mdt_index):
                if MDT[j] == "MEND":
                    break

                temp_line = MDT[j]

                for k in range(MAX_ARGS):
                    if ALA[macro_idx][k]:
                        if actual_args[k]:
                            pos = temp_line.find(ALA[macro_idx][k])
                            if pos != -1:
                                replaced_line = temp_line[:pos] + actual_args[k] + temp_line[pos + len(ALA[macro_idx][k]):]
                                temp_line = replaced_line

                expanded_code[expanded_index] = temp_line
                expanded_index += 1
        else:
            expanded_code[expanded_index] = source[i]
            expanded_index += 1


def main():
    source = [
        "MACRO",
        "INCR X",
        "LDA X",
        "ADD =1",
        "STA X",
        "MEND",
        "START",
        "INCR A",
        "INCR B",
        "HLT",
        "END"
    ]

    n = len(source)

    first_pass(source, n)
    second_pass(source, n)

    print("\nMacro Name Table (MNT):")
    for i in range(mnt_index):
        print(f"{MNT[i]}\t{i}")

    print("\nMacro Definition Table (MDT):")
    for i in range(mdt_index):
        print(f"{i}\t{MDT[i]}")

    print("\nArgument List Array (ALA):")
    for i in range(mnt_index):
        print(f"{MNT[i]}\t", end="")
        for j in range(MAX_ARGS):
            if ALA[i][j]:
                print(f"{ALA[i][j]} ", end="")
        print()

    print("\nExpanded Source Code:")
    for i in range(expanded_index):
        print(expanded_code[i])


if __name__ == "__main__":
    main()
