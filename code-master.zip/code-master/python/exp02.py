# Questions
# Aim : To design and implement second pass of a two pass assembler for IBM 360/370
# Processor
# Objective: Develop a program to implement second pass:
# a. To generate Base table
# b. To generate machine code 

# Structure to hold the symbol table
symbols = []

# Structure to hold the machine code
machine_code = []

# First pass of the assembler
def first_pass(fp):
    address = 0
    symbol_count = 0
    
    for line in fp:
        line = line.strip()
        
        label, opcode = line.split() if len(line.split()) > 1 else (line, None)
        
        # Add label to symbol table
        if label:
            symbols.append({'label': label, 'address': address})
            symbol_count += 1

        address += 1

# Second pass of the assembler
def second_pass(fp):
    code_count = 0
    
    for line in fp:
        line = line.strip()
        
        parts = line.split()
        if len(parts) >= 2:
            label = parts[0]
            opcode = parts[1]
            operand = parts[2] if len(parts) > 2 else None
            
            op = int(opcode)
            
            if op == 1:
                machine_code.append({'opcode': op, 'operand': int(operand)})
            else:
                machine_code.append({'opcode': op, 'operand': -1})
            code_count += 1

# Output the symbol table and machine code
def output():
    print("Symbol Table:")
    print("Label\tAddress")
    for symbol in symbols:
        print(f"{symbol['label']}\t{symbol['address']}")
    
    print("\nMachine Code:")
    print("Opcode\tOperand")
    for code in machine_code:
        print(f"{code['opcode']}\t{code['operand']}")

# Main function
def main():
    try:
        with open("input.txt", "r") as fp:
            first_pass(fp)
            fp.seek(0)  # Rewind to the start of the file
            second_pass(fp)
            output()
    except FileNotFoundError:
        print("Error opening file.")

if __name__ == "__main__":
    main()


# input.txt
# START 0
# LOOP 1 5
# LOAD 2 10
# ADD 1 2
# STORE 3 20
# JMP 4 LOOP
# END 5