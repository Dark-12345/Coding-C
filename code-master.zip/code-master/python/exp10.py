# Questions
# Aim : To generate target code.
# Objective: Understand intermediate code generation and code generation phase of compiler.
# Develop a program to generate target code

def generate_target_code(tac):
    reg_count = 1
    var_to_reg = {}
    target_code = []

    for line in tac:
        lhs, expr = line.split('=')
        lhs = lhs.strip()
        parts = expr.strip().split()

        if len(parts) == 3:
            op1, operator, op2 = parts
            r = f"R{reg_count}"
            target_code.append(f"MOV {op1}, {r}")
            target_code.append(f"{operator.upper()} {op2}, {r}")
            target_code.append(f"MOV {r}, {lhs}")
            reg_count += 1
        elif len(parts) == 1:
            target_code.append(f"MOV {parts[0]}, {lhs}")
        else:
            target_code.append(f"# Cannot parse: {line}")

    return target_code

# Sample Three-Address Code (TAC)
tac_code = [
    "t1 = a + b",
    "t2 = t1 * c",
    "t3 = t2 - d",
    "t4 = t3 / e"
]

# Generate and display target code
target = generate_target_code(tac_code)

print("Target Code:")
for line in target:
    print(line)
