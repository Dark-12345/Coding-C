# Questions
# Aim : To implement any code optimization techniques
# Objective: Develop a program to implement following code optimization techniques:
# a. Common sub-expression elimination
# b. Reduction in strength 

import re

def eliminate_common_subexpressions(code_lines):
    expr_map = {}
    optimized = []

    for line in code_lines:
        line = line.strip()
        if '=' in line:
            lhs, rhs = map(str.strip, line.split('='))
            if rhs in expr_map:
                optimized.append(f"{lhs} = {expr_map[rhs]}")
            else:
                expr_map[rhs] = lhs
                optimized.append(line)
        else:
            optimized.append(line)
    return optimized

def reduce_strength(code_lines):
    optimized = []
    for line in code_lines:
        line = line.strip()
        line = re.sub(r'(\w+)\s*\*\s*2', r'\1 + \1', line)  # x * 2 → x + x
        line = re.sub(r'(\w+)\s*\*\s*4', r'(\1 + \1) + (\1 + \1)', line)  # x * 4 → (x + x) + (x + x)
        optimized.append(line)
    return optimized

# Sample input code
code = [
    "a = b + c",
    "d = b + c",
    "e = x * 2",
    "f = y * 4"
]

# Apply optimizations
print("Original Code:")
for line in code:
    print(line)

code = eliminate_common_subexpressions(code)
code = reduce_strength(code)

print("\nOptimized Code:")
for line in code:
    print(line)
