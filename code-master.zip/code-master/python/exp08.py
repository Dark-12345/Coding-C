# Questions
# Aim : To implement any parsing technique.
# Objective: Develop a program to implement
# a. Predictive parser
# b. Operator precedence parser

# Predictive Parser (for LL(1) grammar)
import re

table = {
    'E': {'id': 'T G', '(': 'T G'},
    'G': {'+': '+ T G', ')': 'ε', '$': 'ε'},
    'T': {'id': 'F H', '(': 'F H'},
    'H': {'+': 'ε', '*': '* F H', ')': 'ε', '$': 'ε'},
    'F': {'id': 'id', '(': '( E )'}
}

# Tokenize input
raw_input = input("Enter input string (e.g., id+id*id): ")
tokens = re.findall(r'id|\+|\*|\(|\)', raw_input)
tokens.append('$')

stack = ['$','E']
i = 0

while stack:
    top = stack.pop()
    current = tokens[i]

    if top == current == '$':
        print("String Accepted")
        break
    elif top == current:
        i += 1
    elif top in table and current in table[top]:
        production = table[top][current]
        if production != 'ε':
            for symbol in reversed(production.split()):
                stack.append(symbol)
    else:
        print("String Rejected")
        break

# Operator Precedence Parser
import re

# Define precedence table
precedence = {
    '+': {'+': '>', '*': '<', 'id': '<', '(': '<', ')': '>', '$': '>'},
    '*': {'+': '>', '*': '>', 'id': '<', '(': '<', ')': '>', '$': '>'},
    'id': {'+': '>', '*': '>', ')': '>', '$': '>'},
    '(': {'+': '<', '*': '<', 'id': '<', '(': '<', ')': '=', '$': ''},
    ')': {'+': '>', '*': '>', ')': '>', '$': '>'},
    '$': {'+': '<', '*': '<', 'id': '<', '(': '<', '$': ''}
}

# Tokenize input string
raw_input = input("Enter input string (e.g., id+id*id): ")
tokens = re.findall(r'id|\+|\*|\(|\)', raw_input)
tokens.append('$')

stack = ['$']
i = 0

# Find top-most terminal from stack
def top_terminal(stack):
    for symbol in reversed(stack):
        if symbol in precedence:
            return symbol
    return '$'

while True:
    a = top_terminal(stack)
    b = tokens[i]

    if a not in precedence or b not in precedence[a] or precedence[a][b] == '':
        print("Error")
        break

    relation = precedence[a][b]

    if relation in ['<', '=']:
        stack.append(b)
        i += 1
    elif relation == '>':
        while True:
            s = stack.pop()
            if not stack:
                print("Error")
                exit()
            a = top_terminal(stack)
            if a in precedence and s in precedence[a] and precedence[a][s] == '<':
                break
        stack.append('E')

    if stack == ['$','E'] and tokens[i] == '$':
        print("String Accepted")
        break
