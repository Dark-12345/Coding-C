// Questions
// Aim : To design and implement second pass of a two pass assembler for IBM 360/370
// Processor
// Objective: Develop a program to implement second pass:
// a. To generate Base table
// b. To generate machine code 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SYMBOLS 1000
#define MAX_CODE_SIZE 1000

// Structure to hold the symbol table
typedef struct {
    char label[10];
    int address;
} symbol;

int symbolCount = 0;
symbol symbols[MAX_SYMBOLS];

// Structure to hold the machine code
typedef struct {
    int opcode;
    int operand;
} code;

int codeCount = 0;
code machineCode[MAX_CODE_SIZE];

// First pass of the assembler
void firstPass(FILE *fp) {
    char line[80];
    int address = 0;

    while (fgets(line, 80, fp) != NULL) {
        if (line[strlen(line) - 1] == '\n') {
            line[strlen(line) - 1] = '\0';
        }

        char *label = strtok(line, " ");
        if (label != NULL) {
            symbols[symbolCount].address = address;
            strcpy(symbols[symbolCount].label, label);
            symbolCount++;
        }

        char *opcode = strtok(NULL, " ");
        if (opcode != NULL) {
            codeCount++;
        }

        address++;
    }
}

// Second pass of the assembler
void secondPass(FILE *fp) {
    char line[80];

    while (fgets(line, 80, fp) != NULL) {
        if (line[strlen(line) - 1] == '\n') {
            line[strlen(line) - 1] = '\0';
        }

        char *label = strtok(line, " ");
        char *opcode = strtok(NULL, " ");
        char *operand = strtok(NULL, " ");

        if (opcode != NULL) {
            int op = atoi(opcode);
            if (op == 1) {
                machineCode[codeCount].opcode = op;
                machineCode[codeCount].operand = atoi(operand);
            } else {
                machineCode[codeCount].opcode = op;
                machineCode[codeCount].operand = -1;
            }
            codeCount++;
        }
    }
}

// Output the symbol table and machine code
void output() {
    printf("Symbol Table:\n");
    printf("Label\tAddress\n");

    for (int i = 0; i < symbolCount; i++) {
        printf("%s\t%d\n", symbols[i].label, symbols[i].address);
    }

    printf("\nMachine Code:\n");
    printf("Opcode\tOperand\n");

    for (int i = 0; i < codeCount; i++) {
        printf("%d\t%d\n", machineCode[i].opcode, machineCode[i].operand);
    }
}

int main() {
    FILE *fp = fopen("input.txt", "r");

    if (fp == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    firstPass(fp);
    rewind(fp);
    secondPass(fp);
    output();
    fclose(fp);

    return 0;
}


// input.txt
// START 0
// LOOP 1 5
// LOAD 2 10
// ADD 1 2
// STORE 3 20
// JMP 4 LOOP
// END 5
