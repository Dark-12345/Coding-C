// Questions
// Aim : To implement any parsing technique.
// Objective: Develop a program to implement
// a. Predictive parser
// b. Operator precedence parser

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 100

// Token list
const char *tokens[] = {"id", "+", "*", "(", ")", "$"};

// LL(1) Parsing Table
const char *table[5][6] = {
    // id     +      *      (      )      $
    {"F H", NULL, NULL, "F H", NULL, NULL},     // E
    {NULL, "+ T G", NULL, NULL, "ε", "ε"},      // G
    {"F H", NULL, NULL, "F H", NULL, NULL},     // T
    {NULL, "ε", "* F H", NULL, "ε", "ε"},       // H
    {"id", NULL, NULL, "( E )", NULL, NULL}     // F
};

const char *non_terminals = "EGTHF";

// Index mapping
int get_token_index(const char *tok) {
    for (int i = 0; i < 6; i++)
        if (strcmp(tokens[i], tok) == 0)
            return i;
    return -1;
}

int get_non_terminal_index(char nt) {
    for (int i = 0; i < 5; i++)
        if (non_terminals[i] == nt)
            return i;
    return -1;
}

// Simple tokenizer
int tokenize(const char *input, char token_list[MAX][10]) {
    int k = 0;
    for (int i = 0; input[i]; ) {
        if (input[i] == '+') strcpy(token_list[k++], "+"), i++;
        else if (input[i] == '*') strcpy(token_list[k++], "*"), i++;
        else if (input[i] == '(') strcpy(token_list[k++], "("), i++;
        else if (input[i] == ')') strcpy(token_list[k++], ")"), i++;
        else if (input[i] == 'i' && input[i+1] == 'd') strcpy(token_list[k++], "id"), i += 2;
        else i++; // skip whitespaces or invalid
    }
    strcpy(token_list[k++], "$");
    return k;
}

void predictive_parser(const char *input) {
    char tokens_list[MAX][10];
    int n = tokenize(input, tokens_list);
    
    char stack[MAX][10];
    int top = 0;
    strcpy(stack[top++], "$");
    strcpy(stack[top++], "E");

    int i = 0;

    while (top > 0) {
        char *top_symbol = stack[--top];
        char *current_token = tokens_list[i];

        if (strcmp(top_symbol, current_token) == 0 && strcmp(top_symbol, "$") == 0) {
            printf("Predictive Parser Output:\nString Accepted\n");
            return;
        } else if (strcmp(top_symbol, current_token) == 0) {
            i++;
            continue;
        } else if (strlen(top_symbol) == 1 && strchr(non_terminals, top_symbol[0])) {
            int row = get_non_terminal_index(top_symbol[0]);
            int col = get_token_index(current_token);
            const char *production = table[row][col];
            if (production == NULL) {
                printf("Predictive Parser Output:\nString Rejected\n");
                return;
            }
            if (strcmp(production, "ε") != 0) {
                char prod_copy[50];
                strcpy(prod_copy, production);
                char *tok = strtok(prod_copy, " ");
                char reversed[10][10]; int r = 0;
                while (tok) {
                    strcpy(reversed[r++], tok);
                    tok = strtok(NULL, " ");
                }
                for (int j = r - 1; j >= 0; j--) {
                    strcpy(stack[top++], reversed[j]);
                }
            }
        } else {
            printf("Predictive Parser Output:\nString Rejected\n");
            return;
        }
    }

    printf("Predictive Parser Output:\nString Rejected\n");
}

// === Operator Precedence Parser ===

const char *prec_table[][7] = {
    // +    *    id   (    )    $    dummy (for index)
    { ">", "<", "<", "<", ">", ">", "+" },
    { ">", ">", "<", "<", ">", ">", "*" },
    { ">", ">", "x", "x", ">", ">", "id" },
    { "<", "<", "<", "<", "=", "x", "(" },
    { ">", ">", "x", "x", ">", ">", ")" },
    { "<", "<", "<", "<", "x", "x", "$" }
};

int get_prec_index(const char *sym) {
    for (int i = 0; i < 6; i++) {
        if (strcmp(prec_table[i][6], sym) == 0)
            return i;
    }
    return -1;
}

const char *get_relation(const char *a, const char *b) {
    int i = get_prec_index(a);
    int j = get_prec_index(b);
    if (i == -1 || j == -1) return "x";
    return prec_table[i][j];
}

void operator_precedence_parser(const char *input) {
    char tokens_list[MAX][10];
    int n = tokenize(input, tokens_list);

    char stack[MAX][10];
    int top = 0;
    strcpy(stack[top++], "$");

    int i = 0;
    while (1) {
        char *a = NULL;
        for (int k = top - 1; k >= 0; k--) {
            if (get_prec_index(stack[k]) != -1) {
                a = stack[k];
                break;
            }
        }
        char *b = tokens_list[i];
        const char *rel = get_relation(a, b);

        if (strcmp(rel, "<") == 0 || strcmp(rel, "=") == 0) {
            strcpy(stack[top++], b);
            i++;
        } else if (strcmp(rel, ">") == 0) {
            while (1) {
                char s[10]; strcpy(s, stack[--top]);
                char *prev = NULL;
                for (int k = top - 1; k >= 0; k--) {
                    if (get_prec_index(stack[k]) != -1) {
                        prev = stack[k];
                        break;
                    }
                }
                if (strcmp(get_relation(prev, s), "<") == 0) break;
                if (top <= 0) {
                    printf("Operator Precedence Parser Output:\nError\n");
                    return;
                }
            }
            strcpy(stack[top++], "E");
        } else {
            printf("Operator Precedence Parser Output:\nError\n");
            return;
        }

        if (strcmp(stack[0], "$") == 0 && strcmp(stack[1], "E") == 0 && strcmp(tokens_list[i], "$") == 0) {
            printf("Operator Precedence Parser Output:\nString Accepted\n");
            return;
        }
    }
}

// === Main ===

int main() {
    const char *input = "id+id*id";

    predictive_parser(input);
    operator_precedence_parser(input);

    return 0;
}
