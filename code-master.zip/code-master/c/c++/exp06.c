//  Questions
//  Aim : Using JFLAP, create a DFA from a given regular expression.
//  Objective: Simulate a program to implement even number of Zero’s in String
//  a. Using Jflap tool
//  b. Using finite automata

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool is_even_zeros(const char *s) {
    char state = 'A';  // A = even number of 0s, B = odd number of 0s

    for (int i = 0; s[i] != '\0'; i++) {
        char c = s[i];

        if (c != '0' && c != '1') {
            return false;  // invalid character
        }

        if (state == 'A') {
            if (c == '0') state = 'B';
        } else if (state == 'B') {
            if (c == '0') state = 'A';
        }
        // '1' keeps the state unchanged
    }

    return state == 'A';  // Accept if even number of 0s
}

int main() {
    const char *test_strings[] = {"0101", "1100", "101010", "1111", "0", "00", ""};
    int n = sizeof(test_strings) / sizeof(test_strings[0]);

    for (int i = 0; i < n; i++) {
        const char *s = test_strings[i];
        bool result = is_even_zeros(s);
        printf("String: %-10s ➜ %s\n", s, result ? "Accepted" : "Rejected");
    }

    return 0;
}
