// Questions
// Aim:To design and implement first pass of a two pass assembler for IBM 360/370 Processor
// Objective:Develop a program to implement first pass:
// a. To search instruction in MOT and return its length
// b. To search instruction in POT and return the routine called
// c. To generate Symbol table
// d. To generate literal table
// e. To generate intermediate code after pass 1 


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main() {
    FILE *f1, *f2, *f3, *f4;
    int lc, sa, l, op1, o, len;
    char m1[20], la[20], op[20], otp[20];

    // Open input file and symbol table output file
    f1 = fopen("input.txt", "r");
    f3 = fopen("symtab.txt", "w");

    // Read the first line from the input file
    fscanf(f1, "%s %s %d", la, m1, &op1);

    // If the first instruction is START
    if (strcmp(m1, "START") == 0) {
        sa = op1;
        lc = sa;
        printf("\t\t%s\t%s\t%d\n", la, m1, op1);
    } else {
        lc = 0;
    }

    // Read the second line and process
    fscanf(f1, "%s %s", la, m1);
    
    // Loop until end of file
    while (!feof(f1)) {
        fscanf(f1, "%s", op);
        printf("\n%d\t%s\t%s\t%s\n", lc, la, m1, op);
        
        // If label is not "-"
        if (strcmp(la, "-") != 0) {
            fprintf(f3, "\n%d\t%s\n", lc, la); // Write label to symbol table
        }

        // Open opcode table
        f2 = fopen("optab.txt", "r");
        fscanf(f2, "%s %d", otp, &o);

        // Check if mnemonic matches any in optab
        while (!feof(f2)) {
            if (strcmp(m1, otp) == 0) {
                lc = lc + 3;
                break;
            }
            fscanf(f2, "%s %d", otp, &o);
        }
        fclose(f2);

        // Handle directives
        if (strcmp(m1, "WORD") == 0) {
            lc = lc + 3;
        } else if (strcmp(m1, "RESW") == 0) {
            op1 = atoi(op);
            lc = lc + (3 * op1);
        } else if (strcmp(m1, "BYTE") == 0) {
            if (op[0] == 'X') {
                lc = lc + 1;
            } else {
                len = strlen(op) - 2;
                lc = lc + len;
            }
        } else if (strcmp(m1, "RESB") == 0) {
            op1 = atoi(op);
            lc = lc + op1;
        }

        // Read next line
        fscanf(f1, "%s %s", la, m1);
    }

    // Print the program length when END is encountered
    if (strcmp(m1, "END") == 0) {
        printf("\nProgram length = %d", lc - sa);
    }

    // Close the files
    fclose(f1);
    fclose(f3);

    return 0;
}


// input.txt
// START 100
// LOOP  LDA  100
//       ADD  200
//       STORE 300
//       JMP  LOOP
//       END

// optab.txt
// LDA  3
// ADD  3
// STORE  3
// JMP  3

// symtab.txt
// 100   LOOP
