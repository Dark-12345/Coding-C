// Questions
// Aim : To generate target code.
// Objective: Understand intermediate code generation and code generation phase of compiler.
// Develop a program to generate target code


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void generate_target_code(char *tac[], int count) {
    int reg_count = 1;
    char lhs[10], op1[10], op2[10], operator;
    char expr[50];

    for (int i = 0; i < count; i++) {
        strcpy(expr, tac[i]);

        char *equal = strchr(expr, '=');
        if (!equal) {
            printf("# Cannot parse: %s\n", expr);
            continue;
        }

        *equal = '\0';  // Split into LHS and RHS
        strcpy(lhs, expr);
        strcpy(expr, equal + 1);

        // Remove leading/trailing whitespace
        while (*lhs == ' ') memmove(lhs, lhs + 1, strlen(lhs));
        while (lhs[strlen(lhs) - 1] == ' ') lhs[strlen(lhs) - 1] = '\0';

        // Parse the expression
        if (sscanf(expr, " %s %c %s", op1, &operator, op2) == 3) {
            printf("MOV %s, R%d\n", op1, reg_count);
            switch (operator) {
                case '+': printf("ADD %s, R%d\n", op2, reg_count); break;
                case '-': printf("SUB %s, R%d\n", op2, reg_count); break;
                case '*': printf("MUL %s, R%d\n", op2, reg_count); break;
                case '/': printf("DIV %s, R%d\n", op2, reg_count); break;
                default: printf("# Unknown operator in: %s\n", tac[i]);
            }
            printf("MOV R%d, %s\n", reg_count, lhs);
            reg_count++;
        } else if (sscanf(expr, " %s", op1) == 1) {
            printf("MOV %s, %s\n", op1, lhs);
        } else {
            printf("# Cannot parse: %s\n", tac[i]);
        }
    }
}

int main() {
    char *tac_code[] = {
        "t1 = a + b",
        "t2 = t1 * c",
        "t3 = t2 - d",
        "t4 = t3 / e"
    };

    int tac_count = sizeof(tac_code) / sizeof(tac_code[0]);

    printf("Target Code:\n");
    generate_target_code(tac_code, tac_count);

    return 0;
}
