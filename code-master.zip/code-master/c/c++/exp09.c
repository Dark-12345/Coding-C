// Questions
// Aim : To implement any code optimization techniques
// Objective: Develop a program to implement following code optimization techniques:
// a. Common sub-expression elimination
// b. Reduction in strength 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LINES 10
#define MAX_LEN 100

// Helper function to trim leading/trailing whitespace
void trim(char *str) {
    char *end;
    while (*str == ' ') str++;
    end = str + strlen(str) - 1;
    while (end > str && (*end == ' ' || *end == '\n')) *end-- = '\0';
}

// Function to check if rhs already exists in expr_map
int find_expr(char expr_map[][MAX_LEN], int map_size, const char *rhs) {
    for (int i = 0; i < map_size; i++) {
        if (strcmp(expr_map[i], rhs) == 0)
            return i;
    }
    return -1;
}

// Function to perform strength reduction
void reduce_strength(char *line) {
    char var[50], op1[50];
    int num;
    if (sscanf(line, "%s = %s * %d", var, op1, &num) == 3) {
        if (num == 2) {
            sprintf(line, "%s = %s + %s", var, op1, op1);
        } else if (num == 4) {
            sprintf(line, "%s = (%s + %s) + (%s + %s)", var, op1, op1, op1, op1);
        }
    }
}

int main() {
    char code[MAX_LINES][MAX_LEN] = {
        "a = b + c",
        "d = b + c",
        "e = x * 2",
        "f = y * 4"
    };
    int line_count = 4;

    char expr_map[MAX_LINES][MAX_LEN];
    char lhs_map[MAX_LINES][MAX_LEN];
    int map_size = 0;

    char optimized[MAX_LINES][MAX_LEN];
    int opt_count = 0;

    printf("Original Code:\n");
    for (int i = 0; i < line_count; i++) {
        printf("%s\n", code[i]);
    }

    for (int i = 0; i < line_count; i++) {
        char line[MAX_LEN];
        strcpy(line, code[i]);

        trim(line);

        char lhs[50], rhs[100];
        char *eq = strchr(line, '=');
        if (eq) {
            *eq = '\0';
            strcpy(lhs, line);
            trim(lhs);
            strcpy(rhs, eq + 1);
            trim(rhs);

            int existing = find_expr(expr_map, map_size, rhs);
            if (existing != -1) {
                sprintf(optimized[opt_count++], "%s = %s", lhs, lhs_map[existing]);
            } else {
                strcpy(expr_map[map_size], rhs);
                strcpy(lhs_map[map_size], lhs);
                map_size++;
                sprintf(optimized[opt_count++], "%s = %s", lhs, rhs);
            }
        } else {
            strcpy(optimized[opt_count++], line);
        }
    }

    // Apply strength reduction
    for (int i = 0; i < opt_count; i++) {
        reduce_strength(optimized[i]);
    }

    printf("\nOptimized Code:\n");
    for (int i = 0; i < opt_count; i++) {
        printf("%s\n", optimized[i]);
    }

    return 0;
}
