// Questions
// Aim: Write a program to implement Lexical Analyzer for given language using Finite
// Automata.
// Objective: Develop a program to implement lexical analyzer using Finite Automata

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>

#define MAX_TOKEN_LEN 100
#define MAX_TOKENS 1000

typedef struct {
    char type[20];
    char value[MAX_TOKEN_LEN];
} Token;

typedef struct {
    char *type;
    char *pattern;
} Pattern;

Pattern patterns[] = {
    {"KEYWORD", "\\<if\\>|\\<else\\>|\\<while\\>|\\<return\\>|\\<int\\>|\\<float\\>|\\<char\\>|\\<void\\>"},
    {"IDENTIFIER", "\\<[a-zA-Z_][a-zA-Z0-9_]*\\>"},
    {"NUMBER", "[0-9]+(\\.[0-9]+)?"},
    {"OPERATOR", "[+\\-*/=<>!]=?|&&|\\|\\|"},
    {"SYMBOL", "[(){};,]"},
    {"STRING", "\"[^\"]*\""},
    {"COMMENT", "//.*|/\\*([\\s\\S]*?)\\*/"}
};

int match_regex(const char *pattern, const char *text, char *matched) {
    regex_t regex;
    regmatch_t match[1];

    if (regcomp(&regex, pattern, REG_EXTENDED) != 0) return 0;

    int status = regexec(&regex, text, 1, match, 0);
    if (status == 0 && match[0].rm_so == 0) {
        int len = match[0].rm_eo;
        strncpy(matched, text, len);
        matched[len] = '\0';
        regfree(&regex);
        return len;
    }

    regfree(&regex);
    return 0;
}

void lexical_analyzer(const char *source_code, Token tokens[], int *token_count) {
    const char *ptr = source_code;
    char matched[MAX_TOKEN_LEN];
    *token_count = 0;

    while (*ptr) {
        while (*ptr == ' ' || *ptr == '\t' || *ptr == '\n') ptr++;

        if (*ptr == '\0') break;

        int matched_len = 0, i;
        for (i = 0; i < sizeof(patterns)/sizeof(Pattern); i++) {
            matched_len = match_regex(patterns[i].pattern, ptr, matched);
            if (matched_len > 0) {
                strcpy(tokens[*token_count].type, patterns[i].type);
                strcpy(tokens[*token_count].value, matched);
                (*token_count)++;
                ptr += matched_len;
                break;
            }
        }

        if (matched_len == 0) {
            // Handle unknown token
            tokens[*token_count].type[0] = '\0';
            tokens[*token_count].value[0] = *ptr;
            tokens[*token_count].value[1] = '\0';
            strcpy(tokens[*token_count].type, "ERROR");
            (*token_count)++;
            ptr++;
        }
    }
}

int main() {
    const char *source_code =
        "int main() {\n"
        "    int a = 10;\n"
        "    float b = 20.5;\n"
        "    if (a < b) {\n"
        "        a = a + 1;\n"
        "    }\n"
        "    // This is a comment\n"
        "}";

    Token tokens[MAX_TOKENS];
    int token_count;

    lexical_analyzer(source_code, tokens, &token_count);

    printf("\nLexical Analysis Output:\n");
    for (int i = 0; i < token_count; i++) {
        printf("%s: %s\n", tokens[i].type, tokens[i].value);
    }

    return 0;
}
