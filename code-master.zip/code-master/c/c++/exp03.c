// Questions
// Aim : To Design and Implement two pass Macro Processor
// Objective: Develop a program to implement two pass macro processor:
// a. To generate Macro definition Table(MDT)
// b. To generate Macro Name table(MNT)
// c. To generate Argument List Array(ALA)
// d. To generate expanded source code



// Input Code: 
//     "MACRO", 
//     "INCR X", 
//     "LDA X", 
//     "ADD =1", 
//     "STA X", 
//     "MEND", 
//     "START", 
//     "INCR A", 
//     "INCR B", 
//     "HLT", 


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LINES 100
#define MAX_LEN 100
#define MAX_ARGS 10

char *MDT[MAX_LINES];
char MNT[MAX_LINES][MAX_LEN];
char ALA[MAX_LINES][MAX_ARGS][MAX_LEN];
char expanded_code[MAX_LINES][MAX_LEN];
int mdt_index = 0, mnt_index = 0, expanded_index = 0;

int get_macro_index(char *name) {
    for (int i = 0; i < mnt_index; i++) {
        if (strcmp(MNT[i], name) == 0)
            return i;
    }
    return -1;
}

void first_pass(char source[][MAX_LEN], int n) {
    int inside_macro = 0;
    char current_macro_name[MAX_LEN];
    int current_macro_index = -1;
    int ala_arg_count = 0;

    for (int i = 0; i < n; i++) {
        char line[MAX_LEN];
        strcpy(line, source[i]);

        char *tokens[MAX_ARGS];
        int token_count = 0;
        char *token = strtok(line, " \t\n");

        while (token) {
            tokens[token_count++] = token;
            token = strtok(NULL, " \t\n");
        }

        if (token_count == 0) continue;

        if (strcmp(tokens[0], "MACRO") == 0) {
            inside_macro = 1;
            continue;
        }

        if (inside_macro) {
            strcpy(current_macro_name, tokens[0]);
            strcpy(MNT[mnt_index], current_macro_name);

            ala_arg_count = 0;
            for (int j = 1; j < token_count; j++) {
                strcpy(ALA[mnt_index][ala_arg_count++], tokens[j]);
            }

            current_macro_index = mdt_index;
            mdt_index++; // Reserve MDT entry for macro name
            inside_macro = 0;
            mnt_index++;
        } else if (current_macro_index != -1) {
            if (strcmp(tokens[0], "MEND") == 0) {
                MDT[current_macro_index] = strdup("MEND");
                current_macro_index = -1;
            } else {
                MDT[mdt_index++] = strdup(source[i]);
            }
        }
    }
}

void second_pass(char source[][MAX_LEN], int n) {
    for (int i = 0; i < n; i++) {
        char line[MAX_LEN];
        strcpy(line, source[i]);

        char *tokens[MAX_ARGS];
        int token_count = 0;
        char *token = strtok(line, " \t\n");

        while (token) {
            tokens[token_count++] = token;
            token = strtok(NULL, " \t\n");
        }

        if (token_count == 0) continue;

        if (strcmp(tokens[0], "MACRO") == 0 || strcmp(tokens[0], "MEND") == 0)
            continue;

        int macro_idx = get_macro_index(tokens[0]);

        if (macro_idx != -1) {
            char *actual_args[MAX_ARGS];
            for (int j = 1; j < token_count; j++) {
                actual_args[j - 1] = tokens[j];
            }

            for (int j = MNT[macro_idx][0] == '\0' ? 1 : MNT[macro_idx][0]; j < mdt_index; j++) {
                if (strcmp(MDT[j], "MEND") == 0) break;

                char temp_line[MAX_LEN];
                strcpy(temp_line, MDT[j]);

                for (int k = 0; k < MAX_ARGS && ALA[macro_idx][k][0] != '\0'; k++) {
                    if (actual_args[k]) {
                        char *pos = strstr(temp_line, ALA[macro_idx][k]);
                        if (pos) {
                            char replaced_line[MAX_LEN];
                            strncpy(replaced_line, temp_line, pos - temp_line);
                            replaced_line[pos - temp_line] = '\0';
                            strcat(replaced_line, actual_args[k]);
                            strcat(replaced_line, pos + strlen(ALA[macro_idx][k]));
                            strcpy(temp_line, replaced_line);
                        }
                    }
                }

                strcpy(expanded_code[expanded_index++], temp_line);
            }
        } else {
            strcpy(expanded_code[expanded_index++], source[i]);
        }
    }
}

int main() {
    char source[][MAX_LEN] = {
        "MACRO",
        "INCR X",
        "LDA X",
        "ADD =1",
        "STA X",
        "MEND",
        "START",
        "INCR A",
        "INCR B",
        "HLT",
        "END"
    };

    int n = sizeof(source) / sizeof(source[0]);

    first_pass(source, n);
    second_pass(source, n);

    printf("\nMacro Name Table (MNT):\n");
    for (int i = 0; i < mnt_index; i++) {
        printf("%s\t%d\n", MNT[i], i);
    }

    printf("\nMacro Definition Table (MDT):\n");
    for (int i = 0; i < mdt_index; i++) {
        printf("%d\t%s\n", i, MDT[i]);
    }

    printf("\nArgument List Array (ALA):\n");
    for (int i = 0; i < mnt_index; i++) {
        printf("%s\t", MNT[i]);
        for (int j = 0; j < MAX_ARGS && ALA[i][j][0] != '\0'; j++) {
            printf("%s ", ALA[i][j]);
        }
        printf("\n");
    }

    printf("\nExpanded Source Code:\n");
    for (int i = 0; i < expanded_index; i++) {
        printf("%s\n", expanded_code[i]);
    }

    return 0;
}

